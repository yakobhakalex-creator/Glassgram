"""Telegram AI V9 — local Qt dashboard. The agent remains a separate process."""
import sys, os, json, time, queue, threading, subprocess, shutil, html, urllib.request, urllib.error
from pathlib import Path
from collections import deque
from messenger_ui import MessengerPage
from PySide6.QtCore import Qt, QTimer, QSize, QPointF
from PySide6.QtGui import QIcon, QPainter, QColor, QPen, QPixmap, QPainterPath, QAction, QFont
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QFrame, QStackedWidget, QLineEdit, QTextEdit, QTextBrowser, QComboBox,
    QSpinBox, QDoubleSpinBox, QCheckBox, QListWidget, QListWidgetItem, QFormLayout, QScrollArea,
    QMessageBox, QFileDialog, QSystemTrayIcon, QMenu, QProgressBar, QSizePolicy)

BASE=Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent
FLAGS=getattr(subprocess,'CREATE_NO_WINDOW',0)
ROLES={'user':'Собеседник','owner':'Ты','assistant':'ИИ'}

def api(path='/api/state',payload=None):
    runtime=json.loads((BASE/'.agent_runtime.json').read_text(encoding='utf-8'))
    if int(runtime['port'])!=8765: raise ValueError('Неверный порт агента')
    req=urllib.request.Request('http://127.0.0.1:8765'+path,data=None if payload is None else json.dumps(payload,ensure_ascii=False).encode(),headers={'Authorization':'Bearer '+runtime['token'],'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=310 if path=='/api/messenger' else (2 if payload is None else 12)) as r: return json.load(r)
    except urllib.error.HTTPError as e:
        try: msg=json.load(e).get('error',str(e))
        except Exception: msg=str(e)
        raise RuntimeError(msg)

def ollama(path):
    with urllib.request.urlopen('http://127.0.0.1:11434/api/'+path,timeout=2) as r: return json.load(r)

def python_command():
    if not getattr(sys,'frozen',False):
        p=Path(sys.executable)
        return [str(p.with_name('python.exe') if p.name.lower()=='pythonw.exe' else p)]
    for x in ('python.exe','python','py.exe'):
        p=shutil.which(x)
        if p: return [p]
    raise RuntimeError('Python не найден. Установи Python и добавь его в PATH.')

class Spark(QWidget):
    def __init__(self,color):
        super().__init__(); self.color=color; self.values=deque(maxlen=50); self.setMinimumHeight(44)
    def push(self,v):
        self.values.append(max(0,min(100,float(v)))); self.update()
    def paintEvent(self,event):
        if len(self.values)<2: return
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w,h=self.width()-4,self.height()-6
        pts=[QPointF(2+i*w/49,3+h*(1-v/100)) for i,v in enumerate(self.values)]
        path=QPainterPath(pts[0]); [path.lineTo(x) for x in pts[1:]]
        shade=QPainterPath(path); shade.lineTo(pts[-1].x(),h+3); shade.lineTo(pts[0].x(),h+3); shade.closeSubpath()
        c=QColor(self.color); c.setAlpha(30); p.fillPath(shade,c); p.setPen(QPen(QColor(self.color),2)); p.drawPath(path)

def label(text='',kind=None):
    x=QLabel(text); x.setTextFormat(Qt.TextFormat.PlainText); x.setWordWrap(True)
    if kind: x.setObjectName(kind)
    return x

def button(text,fn,kind=None):
    b=QPushButton(text); b.clicked.connect(fn)
    if kind: b.setObjectName(kind)
    return b

def card():
    f=QFrame(); f.setObjectName('card'); l=QVBoxLayout(f); l.setContentsMargins(18,16,18,16); l.setSpacing(9); return f,l

def row(*items):
    l=QHBoxLayout(); l.setSpacing(9)
    for i in items: l.addWidget(i) if isinstance(i,QWidget) else l.addStretch()
    return l

def spin(lo,hi,v,decimal=False):
    x=QDoubleSpinBox() if decimal else QSpinBox(); x.setRange(lo,hi); x.setValue(v)
    if decimal: x.setDecimals(2); x.setSingleStep(.05 if hi==1.5 else .5)
    return x

def combo(items):
    c=QComboBox(); c.addItems(items); return c

def rounded_avatar(path):
    pix=QPixmap(str(path))
    if pix.isNull(): return QIcon()
    pix=pix.scaled(40,40,Qt.AspectRatioMode.KeepAspectRatioByExpanding,Qt.TransformationMode.SmoothTransformation)
    out=QPixmap(40,40); out.fill(Qt.GlobalColor.transparent)
    p=QPainter(out); p.setRenderHint(QPainter.RenderHint.Antialiasing); mask=QPainterPath(); mask.addEllipse(0,0,40,40); p.setClipPath(mask); p.drawPixmap((40-pix.width())//2,(40-pix.height())//2,pix); p.end(); return QIcon(out)

class App(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle('Telegram AI · V9'); self.resize(1170,800); self.setMinimumSize(900,650)
        self.proc=None; self.server=None; self.starting=False; self.connected=False; self.data={}; self.jobs=queue.Queue(); self.results=queue.Queue(); self.polling=False; self.hw_busy=False; self.memory_busy=False; self.action_busy=False; self.loaded=False; self.current=None; self.memory_payload=None; self.last_logs=''; self.quitting=False; self.theme='dark'
        try: self.theme=json.loads((BASE/'ui_preferences.json').read_text())['theme']
        except Exception: pass
        self.icon=QIcon(str(BASE/'app.ico')); self.setWindowIcon(self.icon)
        root=QWidget(); root.setObjectName('root'); self.setCentralWidget(root); layout=QHBoxLayout(root); layout.setContentsMargins(0,0,0,0); layout.setSpacing(0)
        side=QFrame(); side.setObjectName('sidebar'); side.setFixedWidth(225); sl=QVBoxLayout(side); sl.setContentsMargins(17,24,17,20); sl.setSpacing(8)
        sl.addWidget(label('Telegram AI','brand')); sl.addWidget(label('LOCAL INTELLIGENCE  /  V9','muted')); sl.addSpacing(24)
        self.nav=QListWidget(); self.nav.setObjectName('nav'); self.nav.setSpacing(4); self.nav.setFrameShape(QFrame.Shape.NoFrame)
        for x in ('Обзор','Чаты','Память','Модель','Мониторинг','Журнал','Настройки','Мессенджер'): self.nav.addItem(x)
        sl.addWidget(self.nav,1); sl.addWidget(label('Qwen3.5 9B','section')); sl.addWidget(label('Локальная модель · Ollama','muted')); sl.addWidget(button('Свернуть в трей',self.hide_to_tray)); layout.addWidget(side)
        main=QWidget(); ml=QVBoxLayout(main); ml.setContentsMargins(28,24,28,22); ml.setSpacing(14)
        self.page_title=label('Обзор','heading'); self.status=label('●  Не подключён','status'); ml.addLayout(row(self.page_title,None,self.status))
        self.start_btn=button('Запустить',self.start,'primary'); self.stop_btn=button('Остановить',self.stop,'danger'); self.pause_btn=button('Пауза всех чатов',self.toggle_pause); self.unload_btn=button('Выгрузить модель',self.unload)
        ml.addLayout(row(self.start_btn,self.stop_btn,self.pause_btn,self.unload_btn,None))
        self.stack=QStackedWidget(); ml.addWidget(self.stack,1); self.footer=label('Все настройки и переписки хранятся локально.','muted'); ml.addWidget(self.footer); layout.addWidget(main,1)
        self.build_overview(); self.build_chats(); self.build_memory(); self.build_model(); self.build_monitor(); self.build_log(); self.build_preferences(); self.messenger=MessengerPage(self,api); self.stack.addWidget(self.messenger)
        self.nav.currentRowChanged.connect(self.switch_page); self.nav.setCurrentRow(0); self.apply_theme(self.theme)
        self.tray=QSystemTrayIcon(self.icon,self); menu=QMenu(); show=menu.addAction('Открыть Telegram AI'); show.triggered.connect(self.restore_window); stop=menu.addAction('Остановить агента'); stop.triggered.connect(self.stop); quit=menu.addAction('Выход'); quit.triggered.connect(self.quit_app); self.tray.setContextMenu(menu); self.tray.messageClicked.connect(self.messenger.open_notification); self.tray.activated.connect(lambda reason:self.restore_window() if reason in (QSystemTrayIcon.ActivationReason.Trigger,QSystemTrayIcon.ActivationReason.DoubleClick) else None)
        if QSystemTrayIcon.isSystemTrayAvailable(): self.tray.show()
        else: self.tray.setVisible(False)
        threading.Thread(target=self.worker,daemon=True).start(); self.timer=QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(150); self.poll_timer=QTimer(self); self.poll_timer.timeout.connect(self.poll); self.poll_timer.start(1500); self.hw_timer=QTimer(self); self.hw_timer.timeout.connect(self.sample); self.hw_timer.start(4000); self.poll(); self.sample(); self.update_buttons()
    def page(self):
        w=QWidget(); w.setObjectName("stackPage"); w.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True); l=QVBoxLayout(w); l.setContentsMargins(0,3,0,0); l.setSpacing(13); self.stack.addWidget(w); return l
    def build_overview(self):
        l=self.page(); hero,hl=card(); hl.addWidget(label('Твой персональный агент','section')); self.summary=label('Запусти агент, чтобы подключиться к Telegram.','muted'); hl.addWidget(self.summary); l.addWidget(hero)
        self.metrics={}; grid=QGridLayout(); grid.setSpacing(12)
        for i,(key,title,color) in enumerate([('cpu','Процессор','#0a84ff'),('gpu','Видеокарта','#bf7af0'),('vram','Видеопамять','#32d49b'),('ram','Оперативная память','#ffae55')]):
            f,cl=card(); cl.addWidget(label(title,'muted')); v=label('—','number'); cl.addWidget(v); graph=Spark(color); cl.addWidget(graph); grid.addWidget(f,i//2,i%2); self.metrics[key]=(v,graph)
        l.addLayout(grid); f,cl=card(); cl.addWidget(label('Производительность агента','section')); self.stats=label('Нет данных.'); cl.addWidget(self.stats); l.addWidget(f); l.addStretch()
    def build_chats(self):
        l=self.page(); l.addWidget(label('Управление разрешёнными чатами. Добавляй только согласившихся собеседников.','muted'))
        h=QHBoxLayout(); left,ll=card(); right,rl=card(); ll.addWidget(label('Белый список','section')); self.allow=QTextEdit(); self.allow.setPlaceholderText('ID, каждый с новой строки'); self.allow.setMaximumHeight(105); ll.addWidget(self.allow); ll.addWidget(button('Сохранить список',self.save_allow,'primary')); self.chat_list=QListWidget(); self.chat_list.setIconSize(QSize(38,38)); self.chat_list.currentItemChanged.connect(self.select_chat); ll.addWidget(self.chat_list,1)
        self.chat_title=label('Выбери собеседника','section'); rl.addWidget(self.chat_title); rl.addWidget(label('Индивидуальные заметки','muted')); self.notes=QTextEdit(); self.notes.setPlaceholderText('Контекст общения'); rl.addWidget(self.notes,1); rl.addWidget(button('Сохранить заметки',lambda:self.chat_action('notes',notes=self.notes.toPlainText()))); rl.addWidget(button('Пауза на 60 секунд',lambda:self.chat_action('pause'))); rl.addWidget(button('Открыть память',self.open_memory)); rl.addWidget(button('Очистить память и игру',self.clear_memory,'danger')); rl.addWidget(button('Возобновить после нового согласия',self.resume_chat)); h.addWidget(left,1); h.addWidget(right,1); l.addLayout(h,1)
    def build_memory(self):
        l=self.page(); self.memory_select=QComboBox(); self.memory_select.currentIndexChanged.connect(self.refresh_memory); l.addLayout(row(self.memory_select,button('Обновить',self.refresh_memory),button('Экспорт TXT',self.export_memory),None)); self.memory_info=label('Выбери чат.','muted'); l.addWidget(self.memory_info); self.memory_view=QTextBrowser(); self.memory_view.setOpenExternalLinks(False); self.memory_view.setOpenLinks(False); l.addWidget(self.memory_view,1); l.addWidget(label('До 100 записей на собеседника. Память не является полной перепиской Telegram.','muted'))
    def build_model(self):
        l=self.page(); sc=QScrollArea(); sc.setWidgetResizable(True); sc.setFrameShape(QFrame.Shape.NoFrame); host=QWidget(); host.setObjectName("stackPage"); host.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True); c=QVBoxLayout(host); c.setContentsMargins(0,0,5,0)
        f,cl=card(); cl.addWidget(label('Параметры генерации','section')); form=QFormLayout(); form.setSpacing(12)
        self.context=combo(['4096','8192','16384','32768']); self.short_context=combo(['4096','8192','16384']); self.temp=spin(0,1.5,.65,True); self.think=combo(['auto','off','on']); self.adaptive=QCheckBox('Адаптивный контекст'); self.review=QCheckBox('Самопроверка сложных заданий'); self.chat_limit=spin(64,512,128); self.photo_limit=spin(64,768,192); self.delay=spin(.5,8,2,True); self.cooldown=spin(0,600,5); self.cooldown.setSuffix(' сек.'); self.delay.setSuffix(' сек.')
        for name,x in [('Максимальный контекст',self.context),('Короткий контекст',self.short_context),('Температура',self.temp),('Рассуждения',self.think),('Лимит чата (токены)',self.chat_limit),('Лимит фото (токены)',self.photo_limit),('Объединение сообщений',self.delay),('Кулдаун после твоего сообщения',self.cooldown)]: form.addRow(name,x)
        cl.addLayout(form); cl.addWidget(self.adaptive); cl.addWidget(self.review); cl.addWidget(label('Кулдаун действует только в чате, где ты сам отправил сообщение. 0 — без временной паузы.','muted')); c.addWidget(f)
        f,cl=card(); cl.addWidget(label('Дополнительные инструкции','section')); self.instructions=QTextEdit(); self.instructions.setMinimumHeight(100); cl.addWidget(self.instructions); c.addWidget(f); c.addStretch(); sc.setWidget(host); l.addWidget(sc,1); l.addWidget(button('Применить настройки',self.save_config,'primary'))
    def build_monitor(self):
        l=self.page(); f,cl=card(); cl.addWidget(label('Состояние оборудования','section')); self.hw_details=label('Ожидание измерений…'); cl.addWidget(self.hw_details); self.ollama_status=label('Ollama: —','muted'); cl.addWidget(self.ollama_status); l.addWidget(f); self.monitor_graphs={}
        grid=QGridLayout()
        for i,(k,t,color) in enumerate([('cpu','CPU','#0a84ff'),('gpu','GPU','#bf7af0'),('ram','RAM','#ffae55'),('vram','VRAM','#32d49b')]):
            f,cl=card(); cl.addWidget(label(t,'section')); g=Spark(color); g.setMinimumHeight(90); cl.addWidget(g); grid.addWidget(f,i//2,i%2); self.monitor_graphs[k]=g
        l.addLayout(grid,1); l.addWidget(label('Измерения каждые 4 секунды. Графики показывают историю текущего запуска.','muted'))
    def build_log(self):
        l=self.page(); l.addLayout(row(label('Журнал событий','section'),None,button('Открыть agent.log',lambda:self.open_file('agent.log')),button('Открыть startup.log',lambda:self.open_file('startup.log')))); self.log=QTextEdit(); self.log.setReadOnly(True); l.addWidget(self.log,1)
    def build_preferences(self):
        l=self.page(); f,cl=card(); cl.addWidget(label('Внешний вид','section')); self.theme_select=combo(['Тёмная','Светлая']); self.theme_select.setCurrentIndex(1 if self.theme=='light' else 0); self.theme_select.currentIndexChanged.connect(lambda i:self.apply_theme('light' if i==1 else 'dark')); cl.addLayout(row(label('Тема'),None,self.theme_select)); cl.addWidget(label('Стиль macOS: мягкие панели и скругления. Системное стекло macOS не используется.','muted')); l.addWidget(f)
        f,cl=card(); cl.addWidget(label('Локальные файлы','section')); cl.addWidget(label(str(BASE),'muted')); cl.addWidget(button('Открыть папку агента',lambda:self.open_file('.'))); cl.addWidget(label('Закрытие окна сворачивает приложение в трей, если он доступен. Выход — через меню трея.','muted')); l.addWidget(f); l.addStretch()
    def switch_page(self,i):
        if not 0 <= i < self.stack.count():
            return
        # A full-page opacity effect can leave stale pixels on Windows,
        # especially when switching to a page containing a scroll area.
        # Let QStackedWidget manage visibility without compositing effects.
        self.stack.setCurrentIndex(i)
        self.page_title.setText(self.nav.item(i).text())
        self.stack.update()
        self.stack.currentWidget().update()
        if i == 2:
            self.refresh_memory()
        if i == 7:
            self.messenger.shown()
    def apply_theme(self,theme):
        self.theme=theme; dark=theme!='light'; bg='#101216' if dark else '#f1f3f7'; side='#191c23' if dark else '#e5e9f0'; panel='#1f242e' if dark else '#ffffff'; field='#151922' if dark else '#f6f8fc'; fg='#eef1f7' if dark else '#182130'; muted='#a3adbf' if dark else '#627087'; border='#323a49' if dark else '#dce2ec'; hover='#303b4c' if dark else '#e0e8f4'; danger='#ff8585' if dark else '#b32635'
        self.setStyleSheet(f'''QWidget {{font-family: "Segoe UI"; font-size: 13px; color:{fg};}} QWidget#root, QWidget#stackPage, QStackedWidget, QScrollArea {{background:{bg};}} QFrame#sidebar {{background:{side}; border-right:1px solid {border};}} QFrame#card {{background:{panel}; border:1px solid {border}; border-radius:17px;}} QLabel#heading {{font-size:29px;font-weight:700;}} QLabel#brand {{font-size:23px;font-weight:700;}} QLabel#section {{font-size:16px;font-weight:600;}} QLabel#number {{font-size:25px;font-weight:650;}} QLabel#muted {{color:{muted};font-size:12px;}} QLabel#status {{color:{muted};font-weight:600;}} QPushButton {{background:{panel};border:1px solid {border};border-radius:9px;padding:9px 14px;font-weight:600;}} QPushButton:hover {{background:{hover};}} QPushButton:disabled {{color:{muted};border:1px solid {border};}} QPushButton#primary {{background:#0a72e7;color:white;border:none;}} QPushButton#primary:hover {{background:#2589ff;}} QPushButton#primary:disabled {{background:{hover};color:{muted};}} QPushButton#danger {{color:{danger};}} QLineEdit,QTextEdit,QTextBrowser,QComboBox,QSpinBox,QDoubleSpinBox,QListWidget {{background:{field};border:1px solid {border};border-radius:10px;padding:7px;selection-background-color:#1768cb;selection-color:white;}} QListWidget#nav {{background:transparent;border:none;padding:0;outline:0;}} QListWidget::item {{padding:9px;border-radius:8px;}} QListWidget::item:selected {{background:#1768cb;color:white;}} QListWidget::item:hover:!selected {{background:{hover};}} QComboBox QAbstractItemView {{background:{panel};color:{fg};selection-background-color:#1768cb;}} QScrollBar:vertical {{background:transparent;width:9px;}} QScrollBar::handle:vertical {{background:{border};border-radius:4px;min-height:28px;}} QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical {{height:0;}} QMenu {{background:{panel};border:1px solid {border};}} QMenu::item:selected {{background:#1768cb;color:white;}}''')
        try:(BASE/'ui_preferences.json').write_text(json.dumps({'theme':theme}),encoding='utf-8')
        except OSError:pass
        if self.memory_payload:self.render_memory(self.memory_payload)
    def worker(self):
        while True:
            kind,fn=self.jobs.get()
            try:self.results.put((kind,True,fn()))
            except Exception as e:self.results.put((kind,False,str(e)))
    def submit(self,kind,fn): self.jobs.put((kind,fn))
    def poll(self):
        if not self.polling and not self.action_busy:
            self.polling=True; self.submit('state',api)
    def sample(self):
        if self.hw_busy:return
        self.hw_busy=True
        def get():
            d={}; details=[]
            try:
                import psutil
                cpu=psutil.cpu_percent(interval=.2); r=psutil.virtual_memory(); d['cpu']=(cpu,f'{cpu:.0f}%'); d['ram']=(r.percent,f'{r.used/2**30:.1f} / {r.total/2**30:.1f} ГБ')
            except Exception:details.append('CPU/RAM: psutil недоступен')
            try:
                p=subprocess.run(['nvidia-smi','--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=3,creationflags=FLAGS,check=True); u,a,b,t=map(float,p.stdout.splitlines()[0].split(',')); d['gpu']=(u,f'{u:.0f}%'); d['vram']=(a/b*100,f'{a/1024:.1f} / {b/1024:.1f} ГБ'); details.append(f'Температура GPU: {t:.0f} °C')
            except Exception:details.append('GPU: nvidia-smi недоступна')
            try:
                models=ollama('ps').get('models',[]); d['ollama']='Ollama: '+(', '.join(f'{m.get("name",m.get("model",""))} · GPU {100*m.get("size_vram",0)/max(1,m.get("size",0)):.0f}% · контекст {m.get("context_length","—")}' for m in models) if models else 'модель не загружена')
            except Exception:d['ollama']='Ollama: не подключена'
            d['details']='\n'.join(details); return d
        threading.Thread(target=lambda:self._hardware(get),daemon=True).start()
    def _hardware(self,fn):
        try:self.results.put(('hardware',True,fn()))
        except Exception as e:self.results.put(('hardware',False,str(e)))
    def tick(self):
        while True:
            try:k,ok,v=self.results.get_nowait()
            except queue.Empty:break
            if k=='state':
                self.polling=False
                if ok:self.update_data(v)
                else:self.disconnected()
            elif k=='hardware':
                self.hw_busy=False
                if ok:
                    for key,(lbl,g) in self.metrics.items():
                        if key in v: p,t=v[key]; lbl.setText(t); g.push(p); self.monitor_graphs[key].push(p)
                        else:lbl.setText('—')
                    self.hw_details.setText(v['details'] or 'Датчики доступны'); self.ollama_status.setText(v['ollama'])
            elif k=='memory':
                self.memory_busy=False
                if ok and self.memory_select.currentData()==v['cid'] and any(cid==v['cid'] and st!='нет согласия' for cid,st,_ in self.data.get('chats',[])):self.render_memory(v)
                elif not ok:self.memory_info.setText(v);self.memory_view.clear();self.memory_payload=None
                elif ok and self.memory_select.currentData()!=v['cid']:self.refresh_memory()
            elif k.startswith('action:'):
                self.action_busy=False; op=k.split(':',1)[1]
                if ok:
                    if op=='allow':self.allow.setPlainText('\n'.join(map(str,v['ids'])))
                    self.update_data(v); self.footer.setText('Настройки сохранены.' if op=='config' else 'Действие выполнено.')
                    if op in ('clear','allow'): self.refresh_memory()
                    if op=='shutdown' and self.quitting:self.finish_quit()
                else:
                    self.quitting=False; self.error(v)
            elif k=='launch':
                self.starting=False
                if not ok:self.error(v)
                self.poll()
            elif k=='unload':
                if not ok:self.error(v)
                self.sample()
        self.update_buttons()
    def error(self,text):QMessageBox.warning(self,'Telegram AI',str(text))
    def confirm(self,text):return QMessageBox.question(self,'Telegram AI',text)==QMessageBox.StandardButton.Yes
    def update_buttons(self):
        running=self.proc is not None and self.proc.poll() is None
        self.start_btn.setEnabled(not(self.connected or self.starting or running)); self.stop_btn.setEnabled(self.connected or running or self.starting); self.pause_btn.setEnabled(self.connected and not self.action_busy)
    def disconnected(self):
        if self.connected:self.loaded=False
        self.connected=False; self.status.setStyleSheet(''); self.status.setText('●  Запуск…' if self.starting else '●  Не подключён'); self.summary.setText('Агент не подключён. Проверь журнал запуска.')
        for i in range(self.chat_list.count()):
            it=self.chat_list.item(i); it.setText(f'{self.name(it.data(Qt.ItemDataRole.UserRole))}\nнет подключения')
        try:
            f=BASE/'startup.log'
            with f.open('rb') as stream:stream.seek(max(0,f.stat().st_size-24000)); t=stream.read().decode('utf-8',errors='replace')
            self.set_log('\n'.join(x for x in t.splitlines() if 'token=' not in x))
        except OSError:pass
    def name(self,cid):return self.data.get('names',{}).get(str(cid),str(cid))
    def update_data(self,d):
        self.data=d; self.connected=True; self.starting=False; online=d.get('telegram_connected',True); self.status.setText('●  Общая пауза' if d['paused'] else ('●  В сети' if online else '●  Переподключение')); self.pause_btn.setText('Возобновить все чаты' if d['paused'] else 'Пауза всех чатов'); self.status.setStyleSheet('color:'+('#d99b39' if d['paused'] or not online else '#25a86e'))
        c=d['config']; st=d['stats']; self.summary.setText(f'Qwen3.5 9B   •   {c["context"]:,} токенов   •   {len(d["ids"])} разрешённых чатов   •   кулдаун {c.get("manual_pause",5)} с'); self.stats.setText(f'Запросы: {st["requests"]}     Ошибки: {st["errors"]}     Токены: {st["tokens"]}\nПоследняя генерация: {st["last_seconds"]} с · {st["last_tps"]} ток/с     Среднее: {st["seconds"]/max(1,st["requests"]):.2f} с')
        if not self.loaded:
            self.allow.setPlainText('\n'.join(map(str,d['ids']))); self.load_config(c); self.loaded=True
        old=[self.chat_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.chat_list.count())]
        if old!=d['ids']:
            self.chat_list.blockSignals(True); self.chat_list.clear()
            for cid in d['ids']:
                it=QListWidgetItem();it.setData(Qt.ItemDataRole.UserRole,cid);self.chat_list.addItem(it)
                if cid==self.current:self.chat_list.setCurrentItem(it)
            self.chat_list.blockSignals(False)
            if self.current not in d['ids']:self.current=None; self.chat_title.setText('Выбери собеседника'); self.notes.clear()
        for i,(cid,status,note) in enumerate(d['chats']):
            it=self.chat_list.item(i); it.setText(f'{self.name(cid)}\n{cid} · {status}')
            p=BASE/'avatars'/f'{cid}.jpg'; it.setIcon(rounded_avatar(p) if status!='нет согласия' and p.exists() else QIcon())
            if cid==self.current:self.chat_title.setText(f'{self.name(cid)} · {status}')
        options=[(self.name(cid)+' · '+str(cid),cid) for cid in d['ids']]; before=self.memory_select.currentData()
        if [(self.memory_select.itemText(i),self.memory_select.itemData(i)) for i in range(self.memory_select.count())]!=options:
            self.memory_select.blockSignals(True);self.memory_select.clear()
            for name,cid in options:self.memory_select.addItem(name,cid)
            self.memory_select.setCurrentIndex(self.memory_select.findData(before)); self.memory_select.blockSignals(False)
        if self.memory_payload and not any(cid==self.memory_payload['cid'] and status!='нет согласия' for cid,status,_ in d['chats']):self.memory_payload=None;self.memory_view.clear();self.memory_info.setText('Память недоступна.')
        self.set_log('\n'.join(d['logs']))
    def set_log(self,t):
        if t!=self.last_logs:self.last_logs=t;self.log.setPlainText(t);self.log.verticalScrollBar().setValue(self.log.verticalScrollBar().maximum())
    def load_config(self,c):
        self.context.setCurrentText(str(c['context'])); self.short_context.setCurrentText(str(c.get('short_context',8192))); self.temp.setValue(c['temperature']); self.think.setCurrentText(c['think']); self.adaptive.setChecked(c.get('adaptive',True));self.review.setChecked(c['review']); self.chat_limit.setValue(c.get('chat_limit',128));self.photo_limit.setValue(c.get('photo_limit',192));self.delay.setValue(c.get('delay',2));self.cooldown.setValue(c.get('manual_pause',5));self.instructions.setPlainText(c['instructions'])
    def save_config(self):
        self.action('config',config={'context':int(self.context.currentText()),'short_context':int(self.short_context.currentText()),'temperature':self.temp.value(),'think':self.think.currentText(),'adaptive':self.adaptive.isChecked(),'review':self.review.isChecked(),'chat_limit':self.chat_limit.value(),'photo_limit':self.photo_limit.value(),'delay':self.delay.value(),'manual_pause':self.cooldown.value(),'instructions':self.instructions.toPlainText()})
    def action(self,op,**kwargs):
        if not self.connected:self.error('Сначала запусти агент.');return False
        if self.action_busy:self.footer.setText('Дождись завершения предыдущего действия.');return False
        self.action_busy=True; self.submit('action:'+op,lambda:api('/api/action',{'op':op,**kwargs}));return True
    def save_allow(self):
        if self.confirm('Сохраняем список чатов, согласившихся на обработку сообщений?'):self.action('allow',ids=self.allow.toPlainText())
    def select_chat(self,it,old):
        if it is None:return
        self.current=it.data(Qt.ItemDataRole.UserRole)
        for cid,status,note in self.data.get('chats',[]):
            if cid==self.current:self.chat_title.setText(f'{self.name(cid)} · {status}');self.notes.setPlainText(note);break
    def chat_action(self,op,**kw):
        if self.current is None:self.error('Сначала выбери чат.');return
        self.action(op,cid=self.current,**kw)
    def clear_memory(self):
        if self.current is not None and self.confirm('Удалить локальную память и игру? Переписка Telegram останется.'):self.chat_action('clear')
    def resume_chat(self):
        if self.current is not None and self.confirm('Собеседник снова дал согласие?'):self.chat_action('resume',consent='yes')
    def open_memory(self):
        if self.current is not None:self.memory_select.setCurrentIndex(self.memory_select.findData(self.current));self.nav.setCurrentRow(2)
    def refresh_memory(self,*_):
        cid=self.memory_select.currentData()
        if self.memory_payload and self.memory_payload['cid']!=cid:self.memory_payload=None;self.memory_view.clear()
        if not self.connected or cid is None or self.memory_busy:return
        self.memory_busy=True;self.memory_payload=None;self.memory_view.clear();self.submit('memory',lambda:api('/api/memory?cid='+str(int(cid))))
    def render_memory(self,d):
        self.memory_payload=d; self.memory_info.setText(f'{self.name(d["cid"])} · {len(d["messages"])} записей · режим: {d["last_mode"]} · игра: {d["game"].get("kind","нет")}'); dark=self.theme!='light'; fg='#eef1f7' if dark else '#172232'; colors={'user':'#323a49' if dark else '#e5eaf2','owner':'#345e96' if dark else '#d5e7ff','assistant':'#214d49' if dark else '#d8f0e8'}; parts=[]
        for m in d['messages']:
            role=m['role']; align='left' if role=='user' else 'right'; body=html.escape(m['text']).replace('\n','<br>'); parts.append(f'<table width="100%" cellspacing="5"><tr><td align="{align}"><table width="83%" bgcolor="{colors.get(role,colors["user"])}" cellpadding="10"><tr><td style="color:{fg}"><small>{html.escape(ROLES.get(role,role))} · #{m["id"]}</small><br>{body}</td></tr></table></td></tr></table>')
        self.memory_view.setHtml(''.join(parts)); self.memory_view.verticalScrollBar().setValue(self.memory_view.verticalScrollBar().maximum())
    def export_memory(self):
        d=self.memory_payload
        if not d or d['cid']!=self.memory_select.currentData():return
        if not self.confirm('Экспорт содержит личную переписку. Сохранить локальный TXT?'):return
        p,_=QFileDialog.getSaveFileName(self,'Экспорт',str(BASE/f'Память_{d["cid"]}.txt'),'Текст (*.txt)')
        if p:
            try:Path(p).write_text('\n\n'.join(f'{ROLES.get(m["role"],m["role"])} [#{m["id"]}]\n{m["text"]}' for m in d['messages']),encoding='utf-8')
            except OSError as e:self.error(e)
    def toggle_pause(self):self.action('global_pause',value='0' if self.data.get('paused') else '1')
    def start(self):
        if self.connected or self.starting or (self.proc and self.proc.poll() is None):return
        if not (BASE/'.env').exists() or not (BASE/'assistant.session').exists():self.error('Не найдены .env или assistant.session. Сначала авторизуй аккаунт, как в V7.');return
        self.starting=True;self.status.setText('●  Запуск…');self.update_buttons()
        def launch():
            try:ollama('tags')
            except Exception:
                self.server=subprocess.Popen(['ollama','serve'],cwd=BASE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=FLAGS)
                for _ in range(20):
                    try:ollama('tags');break
                    except Exception:time.sleep(.5)
                else:raise RuntimeError('Ollama не запустилась. Открой её из меню Пуск.')
            env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONIOENCODING='utf-8',TELEGRAM_AI_DESKTOP='1')
            with (BASE/'startup.log').open('w',encoding='utf-8') as f:self.proc=subprocess.Popen([*python_command(),'-u',str(BASE/'agent.py')],cwd=BASE,env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,creationflags=FLAGS)
            # The independent process is discovered through /api/state.
        self.submit('launch',launch)
    def stop(self):
        if self.connected:self.action('shutdown')
        elif self.proc and self.proc.poll() is None and self.confirm('Завершить ещё не подключившийся процесс агента?'):self.proc.terminate()
        else:self.footer.setText('Агент ещё запускается или уже остановлен.')
    def unload(self):
        if self.connected and not self.data.get('paused'):
            self.error('Сначала поставь все чаты на паузу, чтобы модель не загрузилась снова.');return
        def do():subprocess.run(['ollama','stop','qwen3.5:9b'],capture_output=True,timeout=20,creationflags=FLAGS,check=True)
        self.submit('unload',do)
    def open_file(self,n):
        p=BASE/n
        if not p.exists():self.error('Файл ещё не создан.');return
        if os.name=='nt':os.startfile(str(p))
        else:subprocess.Popen(['xdg-open',str(p)])
    def hide_to_tray(self):
        if self.tray.isVisible():self.hide()
        else:self.showMinimized()
    def restore_window(self):self.showNormal();self.raise_();self.activateWindow()
    def closeEvent(self,event):
        if self.quitting:event.accept();return
        if self.tray.isVisible():event.ignore();self.hide()
        else:event.ignore();self.quit_app()
    def quit_app(self):
        if self.connected:
            box=QMessageBox(self);box.setWindowTitle('Выход');box.setText('Остановить агента перед выходом?');box.setStandardButtons(QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No|QMessageBox.StandardButton.Cancel);answer=box.exec()
            if answer==QMessageBox.StandardButton.Cancel:return
            if answer==QMessageBox.StandardButton.Yes:
                self.quitting=True
                if not self.action('shutdown'):self.quitting=False
                return
        self.finish_quit()
    def finish_quit(self):self.quitting=True;self.tray.hide();QApplication.instance().quit()

if __name__=='__main__':
    app=QApplication(sys.argv);app.setApplicationName('Telegram AI V9');app.setQuitOnLastWindowClosed(False);window=App();window.show();sys.exit(app.exec())
