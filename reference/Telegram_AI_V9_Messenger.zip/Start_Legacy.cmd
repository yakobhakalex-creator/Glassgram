@echo off
cd /d "%~dp0"
python control_legacy.py
if errorlevel 1 pause
