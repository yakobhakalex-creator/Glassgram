@echo off
cd /d "%~dp0"
python -m pip install PySide6 psutil pillow
if errorlevel 1 (
    echo Installation failed. Check Python and pip output.
    echo If no compatible PySide6 wheel exists for your Python version,
    echo install Python 3.13 or 3.14 and use it consistently for agent and UI.
    pause
    exit /b 1
)
echo Installation complete. Run Start_AI.cmd.
pause
