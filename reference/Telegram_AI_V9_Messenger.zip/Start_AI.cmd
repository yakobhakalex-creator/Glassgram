@echo off
cd /d "%~dp0"
python -c "import PySide6" >nul 2>&1
if errorlevel 1 (
    echo PySide6 is missing. Run Install_UI.cmd first.
    echo To open the old panel, run Start_Legacy.cmd.
    pause
    exit /b 1
)
python control.py
if errorlevel 1 pause
