Set fs = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = fs.GetParentFolderName(WScript.ScriptFullName)
sh.Run "pythonw.exe ""control.py""", 0, False
