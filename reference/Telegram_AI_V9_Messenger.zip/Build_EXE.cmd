@echo off
cd /d "%~dp0"
python -m pip install PySide6 pyinstaller
if errorlevel 1 goto fail
python -m PyInstaller --noconfirm --onefile --windowed --name TelegramAI --icon app.ico --distpath . control.py
if errorlevel 1 goto fail
echo TelegramAI.exe is ready. Keep it in this folder with agent.py and your settings.
echo Python and all agent dependencies must remain installed.
pause
exit /b 0
:fail
echo Build failed. Use Start_AI.cmd or Start_AI.vbs.
pause
exit /b 1
