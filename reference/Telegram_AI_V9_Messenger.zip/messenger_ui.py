"""Qt messenger page. Network work never runs on the GUI thread."""
import threading, queue, base64, os
from datetime import datetime
from PySide6.QtCore import Qt, QTimer, QSize, QSettings
from PySide6.QtGui import QPixmap, QIcon
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QLineEdit,QTextEdit,QListWidget,QListWidgetItem,QSplitter,QFileDialog,QInputDialog,QMessageBox,QCheckBox,QDialog,QScrollArea,QApplication,QSystemTrayIcon)

class MessengerPage(QWidget):
    def __init__(self,app,api):
        super().__init__();self.app=app;self.api=api;self.cid=None;self.dialogs=[];self.messages={};self.reply=0;self.more=False;self.query='';self.epoch='';self.seq=0;self.busy=set();self.results=queue.Queue();self.last_notice=None;self.pending_open=None;self.reload=False;self.drafts={}
        self.setObjectName('stackPage');self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground,True)
        root=QVBoxLayout(self);root.setContentsMargins(0,0,0,0)
        split=QSplitter();root.addWidget(split,1)
        left=QWidget();ll=QVBoxLayout(left);ll.setContentsMargins(0,0,6,0)
        self.filter=QLineEdit();self.filter.setPlaceholderText('Поиск чатов');self.filter.textChanged.connect(self.render_dialogs);ll.addWidget(self.filter)
        self.dialog_list=QListWidget();self.dialog_list.currentItemChanged.connect(self.select);ll.addWidget(self.dialog_list,1)
        ll.addWidget(self.btn('Обновить чаты',self.refresh_dialogs));self.notify=QCheckBox('Уведомления Windows');self.notify.setChecked(True);ll.addWidget(self.notify);self.show_text=QCheckBox('Показывать текст уведомлений');self.show_text.setChecked(True);ll.addWidget(self.show_text)
        self.sound=QCheckBox('Звук уведомлений');ll.addWidget(self.sound);split.addWidget(left)
        prefs=QSettings('TelegramAI','Messenger')
        for key,widget,default in [('notify',self.notify,True),('preview',self.show_text,True),('sound',self.sound,False)]:
            widget.setChecked(prefs.value(key,default,type=bool));widget.toggled.connect(lambda checked,k=key:prefs.setValue(k,checked))
        right=QWidget();rl=QVBoxLayout(right);rl.setContentsMargins(6,0,0,0)
        self.title=QLabel('Выбери чат');self.title.setTextFormat(Qt.TextFormat.PlainText);self.title.setObjectName('section');rl.addWidget(self.title)
        self.status=QLabel('История Telegram, не память ИИ');self.status.setTextFormat(Qt.TextFormat.PlainText);rl.addWidget(self.status)
        self.ai=QCheckBox('Автоответчик в этом чате');self.ai.clicked.connect(self.toggle_ai);rl.addWidget(self.ai)
        h=QHBoxLayout();self.search=QLineEdit();self.search.setPlaceholderText('Поиск по переписке');self.search.returnPressed.connect(self.do_search);h.addWidget(self.search,1);h.addWidget(self.btn('Найти',self.do_search));h.addWidget(self.btn('Сброс',self.reset_search));rl.addLayout(h)
        h=QHBoxLayout();self.older=self.btn('Загрузить более старые',self.load_older);h.addWidget(self.older);h.addWidget(self.btn('Обновить',self.refresh_history));h.addWidget(self.btn('Прочитано',self.mark_read));rl.addLayout(h)
        self.timeline=QListWidget();self.timeline.setSpacing(4);self.timeline.setWordWrap(True);self.timeline.setSelectionMode(QListWidget.SelectionMode.SingleSelection);rl.addWidget(self.timeline,1)
        h=QHBoxLayout()
        for t,fn in [('Ответить',self.choose_reply),('Изменить',self.edit),('Удалить',self.delete),('Открыть фото',self.preview),('Скачать файл',self.download)]:h.addWidget(self.btn(t,fn))
        rl.addLayout(h)
        self.reply_label=QLabel('');self.reply_label.setTextFormat(Qt.TextFormat.PlainText);h=QHBoxLayout();h.addWidget(self.reply_label,1);h.addWidget(self.btn('Снять ответ',self.cancel_reply));rl.addLayout(h)
        self.compose=QTextEdit();self.compose.setPlaceholderText('Написать сообщение…');self.compose.setMaximumHeight(85);rl.addWidget(self.compose)
        h=QHBoxLayout();h.addWidget(self.btn('Файл',self.attach));h.addWidget(self.btn('Стикеры',self.sticker_picker));h.addWidget(self.btn('Черновик ИИ',self.draft));self.send_btn=self.btn('Отправить',self.send);self.send_btn.setObjectName('primary');h.addWidget(self.send_btn,1);rl.addLayout(h)
        split.addWidget(right);split.setSizes([270,760]);split.setStretchFactor(1,1)
        self.timer=QTimer(self);self.timer.timeout.connect(self.tick);self.timer.start(300);self.poll=QTimer(self);self.poll.timeout.connect(self.poll_events);self.poll.start(1200)
    def btn(self,text,fn):
        b=QPushButton(text);b.clicked.connect(fn);return b
    def call(self,key,op,**p):
        if key in self.busy:return False
        if not self.app.connected:return False
        self.busy.add(key)
        def run():
            try:self.results.put((key,True,self.api('/api/messenger',{'op':op,**p})))
            except Exception as e:self.results.put((key,False,str(e)))
        threading.Thread(target=run,daemon=True).start();return True
    def refresh_dialogs(self):self.call('dialogs','dialogs')
    def shown(self):self.refresh_dialogs();self.update_ai()
    def poll_events(self):
        if not self.app.connected:return
        self.call('events','events',epoch=self.epoch,since=self.seq)
        if self.isVisible():
            self.update_ai()
            if not self.dialogs:self.refresh_dialogs()
    def render_dialogs(self,*_):
        q=self.filter.text().lower(); self.dialog_list.blockSignals(True);self.dialog_list.clear()
        for d in self.dialogs:
            if q and q not in (d['name']+' '+d['preview']).lower():continue
            it=QListWidgetItem(d['name']+(f"  ·  {d['unread']}" if d['unread'] else '')+'\n'+d['preview']);it.setData(Qt.ItemDataRole.UserRole,d['cid']);self.dialog_list.addItem(it)
            if d['cid']==self.cid:self.dialog_list.setCurrentItem(it)
        self.dialog_list.blockSignals(False)
    def select(self,it,old=None):
        if it:self.open_chat(it.data(Qt.ItemDataRole.UserRole))
    def open_chat(self,cid):
        if self.cid is not None:self.drafts[self.cid]=self.compose.toPlainText()
        self.cid=cid; self.messages={};self.query='';self.search.clear();self.timeline.clear();self.cancel_reply();self.compose.setPlainText(self.drafts.get(cid,''));self.title.setText(next((d['name'] for d in self.dialogs if d['cid']==cid),str(cid)));self.render_dialogs();self.update_ai();self.refresh_history()
    def open_notification(self):
        if self.last_notice is not None:
            self.app.restore_window();self.app.nav.setCurrentRow(7)
            if self.cid!=self.last_notice:self.open_chat(self.last_notice)
    def update_ai(self):
        ids=self.app.data.get('ids',[]);self.ai.setEnabled(self.cid is not None and self.app.connected and 'toggle' not in self.busy);self.ai.setChecked(self.cid in ids)
        if self.cid is not None:
            st=next((s for c,s,_ in self.app.data.get('chats',[]) if c==self.cid),'ИИ выключен');self.status.setText(st+' · история Telegram')
    def toggle_ai(self,on):
        if self.cid is None:return
        if on and not self.app.confirm('Собеседник заранее согласился на автоответы и обработку переписки?'):self.update_ai();return
        if not self.call('toggle','toggle',cid=self.cid,enabled=on,consent='yes' if on else ''):self.update_ai()
    def refresh_history(self):
        if self.cid is not None:
            if not self.call('history','history',cid=self.cid,query=self.query):self.reload=True
    def load_older(self):
        if self.cid and self.messages and self.more:self.call('older','history',cid=self.cid,query=self.query,before=min(self.messages))
    def do_search(self):self.query=self.search.text().strip();self.messages={};self.timeline.clear();self.refresh_history()
    def reset_search(self):self.search.clear();self.do_search()
    def render_history(self,older=False):
        bar=self.timeline.verticalScrollBar(); oldmax=bar.maximum();oldvalue=bar.value();self.timeline.clear()
        for mid,m in sorted(self.messages.items()):
            who=('ИИ' if m['ai'] else 'Ты') if m['out'] else self.title.text();
            try:stamp=datetime.fromisoformat(m['date']).astimezone().strftime('%d.%m %H:%M')
            except Exception:stamp=''
            text=(f"↪ #{m['reply']}\n" if m['reply'] else '')+(f"[{m['kind']}] {m['name']}\n" if m['kind'] else '')+m['text']
            it=QListWidgetItem(f'{who}  ·  {stamp}\n{text}');it.setData(Qt.ItemDataRole.UserRole,mid);it.setTextAlignment(Qt.AlignmentFlag.AlignRight if m['out'] else Qt.AlignmentFlag.AlignLeft)
            from PySide6.QtGui import QColor
            dark=self.app.theme!='light';it.setBackground(QColor(('#204c48' if m['ai'] else '#244c78') if m['out'] else '#292f3a') if dark else QColor(('#d9f2e9' if m['ai'] else '#d6e8ff') if m['out'] else '#e8edf4'));self.timeline.addItem(it)
        if older:bar.setValue(oldvalue+bar.maximum()-oldmax)
        else:self.timeline.scrollToBottom()
        self.older.setEnabled(self.more)
    def selected(self):
        it=self.timeline.currentItem();return self.messages.get(it.data(Qt.ItemDataRole.UserRole)) if it else None
    def choose_reply(self):
        m=self.selected()
        if m:self.reply=m['id'];self.reply_label.setText('Ответ: '+(m['text'] or m['kind'])[:90]);self.compose.setFocus()
    def cancel_reply(self):self.reply=0;self.reply_label.clear()
    def send(self):
        text=self.compose.toPlainText().strip()
        if self.cid is not None and text:
            if self.call('send','send',cid=self.cid,text=text,reply=self.reply):self.sent_snapshot=(self.cid,text,self.reply);self.send_btn.setEnabled(False)
    def attach(self):
        if self.cid is None:return
        p,_=QFileDialog.getOpenFileName(self,'Отправить файл (до 50 МБ)')
        if p and self.app.confirm('Отправить выбранный файл в чат '+self.title.text()+'?'):self.call('file','file',cid=self.cid,path=p,text=self.compose.toPlainText(),reply=self.reply)
    def edit(self):
        m=self.selected()
        if not m or not m['out']:return
        text,ok=QInputDialog.getMultiLineText(self,'Изменить сообщение','Текст',m['text'])
        if ok and text.strip():self.call('edit','edit',cid=self.cid,id=m['id'],text=text)
    def delete(self):
        m=self.selected()
        if not m or not m['out']:return
        box=QMessageBox(self);box.setWindowTitle('Удалить сообщение');box.setText('Удалить выбранное сообщение из Telegram?');both=box.addButton('У обоих',QMessageBox.ButtonRole.DestructiveRole);me=box.addButton('Только у меня',QMessageBox.ButtonRole.ActionRole);box.addButton(QMessageBox.StandardButton.Cancel);box.exec();clicked=box.clickedButton()
        if clicked in (both,me):self.call('delete','delete',cid=self.cid,id=m['id'],revoke=clicked==both)
    def preview(self):
        m=self.selected()
        if m and m['preview']:self.call('preview','preview',cid=self.cid,id=m['id'])
    def download(self):
        m=self.selected()
        if not m or not m['kind']:return
        name=os.path.basename(m['name']) or ('photo.jpg' if m['kind']=='Фото' else 'attachment');p,_=QFileDialog.getSaveFileName(self,'Сохранить вложение',name)
        if p:self.call('download','download',cid=self.cid,id=m['id'],path=p)
    def sticker_picker(self):
        if self.cid is not None:self.call('stickers','stickers')
    def draft(self):
        if self.cid is not None:self.call('draft','draft',cid=self.cid)
    def mark_read(self):
        if self.cid is not None and self.messages:self.call('read','read',cid=self.cid,id=max(self.messages))
    def tick(self):
        while True:
            try:k,ok,v=self.results.get_nowait()
            except queue.Empty:break
            self.busy.discard(k)
            if k=='send':self.send_btn.setEnabled(True)
            if not ok:
                if k not in ('events','dialogs'):self.status.setText(str(v));self.update_ai() if k=='toggle' else None
                if k=='history' and self.reload:self.reload=False;self.refresh_history()
                continue
            if k=='events':
                self.epoch=v['epoch'];self.seq=v['seq']; changed=False
                for e in v['events']:
                    if e['kind']=='delete' and e['cid'] in (0,self.cid):
                        for mid in e['ids']:self.messages.pop(mid,None)
                        self.render_history();changed=True
                    if e['cid']==self.cid:changed=True
                    if e['kind']=='new' and not e['out'] and self.notify.isChecked() and not (self.app.isActiveWindow() and self.isVisible() and self.cid==e['cid']):
                        self.last_notice=e['cid']; name=e['name'] or next((d['name'] for d in self.dialogs if d['cid']==e['cid']),'Telegram AI');self.app.tray.showMessage(name,e['text'] if self.show_text.isChecked() else 'Новое сообщение',QSystemTrayIcon.MessageIcon.Information,5000)
                        if self.sound.isChecked():QApplication.beep()
                if v['events']:self.refresh_dialogs()
                if changed and not self.query:self.refresh_history()
            elif k=='dialogs':self.dialogs=v['dialogs'];self.render_dialogs()
            elif k in ('history','older'):
                if v['cid']==self.cid and v['query']==self.query:
                    if k=='history':
                        fresh={m['id']:m for m in v['messages']}; cutoff=min(fresh,default=0)
                        self.messages={i:m for i,m in self.messages.items() if i<cutoff};self.messages.update(fresh)
                    else:self.messages.update({m['id']:m for m in v['messages']})
                    self.more=v['more'] if k=='older' or len(self.messages)<=40 else self.more;self.render_history(k=='older')
                if k=='history' and self.reload:self.reload=False;self.refresh_history()
            elif k=='send':
                if self.cid==self.sent_snapshot[0] and self.compose.toPlainText().strip()==self.sent_snapshot[1]:self.compose.clear();self.cancel_reply()
                elif self.drafts.get(self.sent_snapshot[0],'').strip()==self.sent_snapshot[1]:self.drafts.pop(self.sent_snapshot[0],None)
                self.refresh_history();self.refresh_dialogs()
            elif k in ('edit','delete','file','sticker','read','toggle'):
                if k=='delete':self.messages={}
                if k=='toggle':self.app.loaded=False;self.app.poll()
                if k in ('file','sticker'):self.cancel_reply()
                self.refresh_history();self.refresh_dialogs()
            elif k=='draft':
                if self.cid==v['cid']:
                    if not self.compose.toPlainText().strip() or self.app.confirm('Заменить текущий текст черновиком ИИ?'):self.compose.setPlainText(v['text'])
            elif k=='preview':
                pix=QPixmap();pix.loadFromData(base64.b64decode(v['data']));
                if pix.isNull():self.status.setText('Не удалось открыть превью');continue
                dlg=QDialog(self);dlg.setWindowTitle('Изображение');lay=QVBoxLayout(dlg);lbl=QLabel();lbl.setPixmap(pix.scaled(800,650,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation));lay.addWidget(lbl);dlg.exec()
            elif k=='download':self.status.setText('Сохранено: '+v['path'])
            elif k=='stickers':
                if not v['stickers']:self.status.setText('Нет недавних стикеров');continue
                dlg=QDialog(self);dlg.setWindowTitle('Недавние стикеры Telegram');dlg.resize(450,460);lay=QVBoxLayout(dlg);lst=QListWidget();lst.setIconSize(QSize(64,64));lay.addWidget(lst)
                for s in v['stickers']:
                    it=QListWidgetItem((s['alt'] or 'Стикер')+'  ·  '+s['id'][-6:]);it.setData(Qt.ItemDataRole.UserRole,s['id']);pix=QPixmap();pix.loadFromData(base64.b64decode(s.get('data','')));it.setIcon(QIcon(pix) if not pix.isNull() else QIcon());lst.addItem(it)
                b=self.btn('Отправить выбранный',dlg.accept);lay.addWidget(b)
                if dlg.exec() and lst.currentItem() and self.cid:self.call('sticker','sticker',cid=self.cid,id=lst.currentItem().data(Qt.ItemDataRole.UserRole),reply=self.reply)
