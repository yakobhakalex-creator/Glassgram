"""Local desktop control panel for Telegram AI V7. Python standard library only."""
import json, os, queue, subprocess, sys, threading, time, urllib.request, urllib.error
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

BASE=Path(__file__).resolve().parent
RUNTIME=BASE/'.agent_runtime.json'
PYTHON=Path(sys.executable)
if PYTHON.name.lower()=='pythonw.exe': PYTHON=PYTHON.with_name('python.exe')
FLAGS=getattr(subprocess,'CREATE_NO_WINDOW',0)
ROLES={'user':'Собеседник','owner':'Ты','assistant':'ИИ'}

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Telegram AI V7 — управление')
        self.geometry('1050x760'); self.minsize(790,570)
        self.configure(bg='#16191f')
        self.proc=None; self.server=None; self.starting=False; self.stop_pending=False; self.start_time=0
        self.connected=False; self.data={}; self.chat_ids=[]; self.current=None; self.memory_payload=None
        self.events=queue.Queue(); self.console=[]; self.log_snapshot=''; self.config_loaded=False; self.allow_loaded=False; self.note_dirty=False
        self.style=ttk.Style(self); self.style.theme_use('clam')
        self.style.configure('.',background='#20252d',foreground='#e2e8f0',fieldbackground='#12161d',bordercolor='#3b4452',font=('Segoe UI',10))
        self.style.configure('TFrame',background='#16191f'); self.style.configure('TLabel',background='#16191f')
        self.style.configure('TButton',padding=(12,7)); self.style.map('TButton',background=[('active','#38475d')])
        self.style.configure('TNotebook',background='#16191f'); self.style.configure('TNotebook.Tab',padding=(14,8))
        self.style.map('TNotebook.Tab',background=[('selected','#3a4c66')]); self.style.configure('Treeview',background='#12161d',fieldbackground='#12161d',rowheight=28)
        self.style.map('Treeview',background=[('selected','#3a4c66')]); self.style.configure('TCheckbutton',background='#16191f')
        header=ttk.Frame(self,padding=12); header.pack(fill='x')
        ttk.Label(header,text='Telegram AI  /  V7',font=('Segoe UI',19,'bold')).pack(side='left')
        self.status=tk.StringVar(value='Не подключён'); ttk.Label(header,textvariable=self.status).pack(side='right')
        toolbar=ttk.Frame(self,padding=(12,0,12,10)); toolbar.pack(fill='x')
        self.start_button=ttk.Button(toolbar,text='Запустить агента',command=self.start); self.start_button.pack(side='left',padx=(0,6))
        self.stop_button=ttk.Button(toolbar,text='Остановить',command=self.stop); self.stop_button.pack(side='left',padx=6)
        self.pause_button=ttk.Button(toolbar,text='Пауза всех чатов',command=self.toggle_pause); self.pause_button.pack(side='left',padx=6)
        ttk.Button(toolbar,text='Выгрузить модель',command=self.unload).pack(side='left',padx=6)
        self.nb=ttk.Notebook(self); self.nb.pack(fill='both',expand=True,padx=12,pady=(0,12))
        self.overview=self.tab('Обзор'); self.chats_tab=self.tab('Чаты'); self.mem_tab=self.tab('Память'); self.settings_tab=self.tab('Модель'); self.log_tab=self.tab('Журнал')
        self.stats_var=tk.StringVar(value='Запусти агента, чтобы увидеть статистику.'); ttk.Label(self.overview,textvariable=self.stats_var,font=('Segoe UI',13),justify='left').pack(anchor='w',pady=12)
        ttk.Label(self.overview,text='Локальный агент • Qwen3.5 9B • Ollama\nНастройки и память остаются в папке TelegramAI.\nДля остановки автоответов можно использовать общую паузу или кнопку «Остановить».',justify='left').pack(anchor='w',pady=12)
        self.hw_var=tk.StringVar(value='CPU / RAM / GPU: ожидание измерений'); ttk.Label(self.overview,textvariable=self.hw_var,justify='left').pack(anchor='w',pady=8)
        self.hw_busy=False; self.after(500,self.hardware_poll)
        self.ollama_var=tk.StringVar(value='Ollama: статус ещё не проверен'); ttk.Label(self.overview,textvariable=self.ollama_var).pack(anchor='w')
        ttk.Button(self.overview,text='Проверить загрузку модели',command=self.check_ollama).pack(anchor='w',pady=10)
        self.make_chats(); self.make_memory(); self.make_settings()
        self.log_text=self.text(self.log_tab, height=18,readonly=True); self.log_text.pack(fill='both',expand=True)
        ttk.Button(self.log_tab,text='Открыть постоянный журнал',command=self.open_log).pack(anchor='w',pady=8)
        self.protocol('WM_DELETE_WINDOW',self.close); self.after(200,self.poll)

    def tab(self,name):
        f=ttk.Frame(self.nb,padding=14); self.nb.add(f,text=name); return f
    def text(self,parent,height=5,readonly=False):
        t=tk.Text(parent,height=height,wrap='word',bg='#12161d',fg='#e2e8f0',insertbackground='#fff',selectbackground='#3a4c66',font=('Segoe UI',11),relief='flat',padx=9,pady=8,undo=not readonly)
        if readonly: t.configure(state='disabled')
        return t
    def replace(self,t,text,readonly=False):
        t.configure(state='normal'); t.delete('1.0','end'); t.insert('1.0',text)
        if readonly: t.configure(state='disabled')
    def make_chats(self):
        frame=ttk.Frame(self.chats_tab); frame.pack(fill='both',expand=True)
        left=ttk.Frame(frame); left.pack(side='left',fill='both',expand=True,padx=(0,12))
        right=ttk.Frame(frame); right.pack(side='left',fill='both',expand=True)
        ttk.Label(left,text='Белый список (согласившиеся чаты)').pack(anchor='w')
        self.allow_text=self.text(left,5); self.allow_text.pack(fill='x',pady=6)
        ttk.Button(left,text='Сохранить белый список',command=lambda:self.action({'op':'allow','ids':self.allow_text.get('1.0','end').strip()})).pack(anchor='w')
        self.tree=ttk.Treeview(left,columns=('id','status'),show='headings',selectmode='browse',height=9)
        self.tree.heading('id',text='ID чата'); self.tree.heading('status',text='Статус'); self.tree.column('id',width=135); self.tree.column('status',width=120)
        self.tree.pack(fill='both',expand=True,pady=10); self.tree.bind('<<TreeviewSelect>>',self.choose_chat)
        self.chat_title=tk.StringVar(value='Выбери чат'); ttk.Label(right,textvariable=self.chat_title,font=('Segoe UI',13,'bold')).pack(anchor='w')
        ttk.Label(right,text='Заметки для нейросети').pack(anchor='w',pady=(10,2))
        self.notes_text=self.text(right,5); self.notes_text.pack(fill='both',expand=True,pady=4)
        ttk.Button(right,text='Сохранить заметки',command=lambda:self.chat_action('notes',notes=self.notes_text.get('1.0','end').strip())).pack(fill='x',pady=3)
        ttk.Button(right,text='Пауза 60 секунд',command=lambda:self.chat_action('pause')).pack(fill='x',pady=3)
        ttk.Button(right,text='Открыть память чата',command=self.open_memory).pack(fill='x',pady=3)
        ttk.Button(right,text='Очистить память и игру',command=self.clear_memory).pack(fill='x',pady=3)
        ttk.Button(right,text='Возобновить после нового согласия',command=self.resume_chat).pack(fill='x',pady=3)
    def make_memory(self):
        row=ttk.Frame(self.mem_tab); row.pack(fill='x')
        ttk.Label(row,text='Чат:').pack(side='left'); self.memory_id=tk.StringVar()
        self.memory_select=ttk.Combobox(row,textvariable=self.memory_id,state='readonly',width=20); self.memory_select.pack(side='left',padx=7); self.memory_select.bind('<<ComboboxSelected>>',lambda e:self.refresh_memory())
        ttk.Button(row,text='Обновить',command=self.refresh_memory).pack(side='left',padx=5)
        ttk.Button(row,text='Экспорт в TXT',command=self.export_memory).pack(side='left',padx=5)
        self.memory_info=tk.StringVar(value='Выбери чат из списка.'); ttk.Label(self.mem_tab,textvariable=self.memory_info).pack(anchor='w',pady=9)
        self.memory_text=self.text(self.mem_tab,20,True); self.memory_text.pack(fill='both',expand=True)
        ttk.Label(self.mem_tab,text='Показывается отдельная память ИИ (до 100 сообщений на чат), а не вся история Telegram.').pack(anchor='w',pady=8)
    def make_settings(self):
        self.context=tk.StringVar(value='16384'); self.temp=tk.StringVar(value='0.65'); self.think=tk.StringVar(value='auto'); self.review=tk.BooleanVar(value=True); self.adaptive=tk.BooleanVar(value=True); self.short_context=tk.StringVar(value='8192'); self.chat_limit=tk.StringVar(value='128'); self.photo_limit=tk.StringVar(value='192'); self.delay=tk.StringVar(value='2')
        for label,var,options in [('Максимальный контекст',self.context,['4096','8192','16384','32768']),('Режим рассуждений (для задач)',self.think,['auto','off','on'])]:
            row=ttk.Frame(self.settings_tab); row.pack(fill='x',pady=6); ttk.Label(row,text=label,width=34).pack(side='left'); ttk.Combobox(row,textvariable=var,values=options,state='readonly',width=16).pack(side='left')
        row=ttk.Frame(self.settings_tab); row.pack(fill='x',pady=6); ttk.Label(row,text='Температура (0–1.5)',width=34).pack(side='left'); ttk.Entry(row,textvariable=self.temp,width=18).pack(side='left')
        speed=ttk.Frame(self.settings_tab); speed.pack(fill='x',pady=5)
        ttk.Checkbutton(speed,text='Адаптивный контекст',variable=self.adaptive).pack(side='left')
        ttk.Label(speed,text='Короткий:').pack(side='left',padx=(12,3)); ttk.Combobox(speed,textvariable=self.short_context,values=['4096','8192','16384'],state='readonly',width=8).pack(side='left')
        limits=ttk.Frame(self.settings_tab); limits.pack(fill='x',pady=5)
        for label,var in [('Чат, токены',self.chat_limit),('Фото, токены',self.photo_limit),('Задержка, с',self.delay)]:
            ttk.Label(limits,text=label).pack(side='left',padx=(0,4)); ttk.Entry(limits,textvariable=var,width=7).pack(side='left',padx=(0,12))
        ttk.Checkbutton(self.settings_tab,text='Самопроверка только сложных заданий',variable=self.review).pack(anchor='w',pady=9)
        ttk.Label(self.settings_tab,text='Дополнительные инструкции владельца').pack(anchor='w',pady=(8,2))
        self.instructions=self.text(self.settings_tab,7); self.instructions.pack(fill='both',expand=True)
        ttk.Button(self.settings_tab,text='Применить настройки',command=self.save_config).pack(anchor='w',pady=8)
        ttk.Label(self.settings_tab,text='Настройки применяются со следующего запроса. Большой контекст может использовать ОЗУ.').pack(anchor='w')
    def api(self,path='/api/state',payload=None):
        runtime=json.loads(RUNTIME.read_text(encoding='utf-8')); port=int(runtime['port'])
        if port!=8765: raise ValueError('Неверный порт локального агента')
        req=urllib.request.Request('http://127.0.0.1:8765'+path,data=None if payload is None else json.dumps(payload,ensure_ascii=False).encode(),headers={'Authorization':'Bearer '+runtime['token'],'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req,timeout=2 if payload is None else 12) as r: return json.load(r)
        except urllib.error.HTTPError as e:
            try: msg=json.load(e).get('error',str(e))
            except Exception: msg=str(e)
            raise RuntimeError(msg)
    def action(self,payload):
        try:
            data=self.api('/api/action',payload); self.update_data(data)
            if payload['op']=='allow': self.allow_loaded=False; self.update_data(data)
            if payload['op']=='clear' and self.memory_id.get()==str(payload['cid']): self.refresh_memory()
            return True
        except Exception as e: messagebox.showerror('Агент',str(e)); return False
    def chat_action(self,op,**extra):
        if self.current is None: messagebox.showinfo('Чаты','Сначала выбери чат.'); return
        self.action({'op':op,'cid':self.current,**extra})
    def choose_chat(self,event=None):
        selected=self.tree.selection()
        if not selected: return
        cid=int(selected[0]); self.current=cid
        entry=next((x for x in self.data.get('chats',[]) if x[0]==cid),None)
        if entry:
            self.chat_title.set(f'{cid} · {entry[1]}'); self.replace(self.notes_text,entry[2])
    def open_memory(self):
        if self.current is None: return
        self.memory_id.set(str(self.current)); self.nb.select(self.mem_tab); self.refresh_memory()
    def clear_memory(self):
        if self.current is not None and messagebox.askyesno('Очистить память','Удалить локальную память и игру этого чата? Переписка Telegram останется.'):
            self.chat_action('clear')
    def resume_chat(self):
        if self.current is not None and messagebox.askyesno('Согласие','Собеседник снова согласился на общение и обработку сообщений?'):
            self.chat_action('resume',consent='yes')
    def refresh_memory(self):
        self.memory_payload=None
        if not self.memory_id.get(): return
        try:
            d=self.api('/api/memory?cid='+str(int(self.memory_id.get())))
            self.memory_payload=d
            self.memory_info.set(f'Чат {d["cid"]} · записей: {len(d["messages"])} · режим: {d["last_mode"]} · игра: {d["game"].get("kind","нет")}')
            self.replace(self.memory_text,self.format_memory(d),True)
        except Exception as e:
            self.memory_info.set(str(e)); self.replace(self.memory_text,'',True)
    @staticmethod
    def format_memory(d):
        return '\n\n'.join(f'{ROLES.get(m["role"],m["role"])}  [#{m["id"]}]\n{m["text"]}' for m in d['messages'])
    def export_memory(self):
        if not self.memory_id.get(): return
        self.refresh_memory(); d=self.memory_payload
        if not d: return
        if not messagebox.askyesno('Экспорт','Файл будет содержать личную переписку. Храни его только у себя. Экспортировать?'): return
        path=filedialog.asksaveasfilename(initialfile=f'Память_{d["cid"]}.txt',defaultextension='.txt',filetypes=[('Текст','*.txt')])
        if path: Path(path).write_text(self.format_memory(d),encoding='utf-8')
    def save_config(self):
        try: cfg={'context':int(self.context.get()),'temperature':float(self.temp.get().replace(',','.')),'think':self.think.get(),'review':self.review.get(),'instructions':self.instructions.get('1.0','end').strip(),'adaptive':self.adaptive.get(),'short_context':int(self.short_context.get()),'chat_limit':int(self.chat_limit.get()),'photo_limit':int(self.photo_limit.get()),'delay':float(self.delay.get().replace(',','.'))}
        except ValueError: messagebox.showerror('Настройки','Проверь температуру и контекст.'); return
        if self.action({'op':'config','config':cfg}): messagebox.showinfo('Настройки','Настройки сохранены.')
    def update_data(self,d):
        self.connected=True; self.starting=False; self.data=d
        self.status.set('Агент запущен · '+('Telegram переподключается' if not d.get('telegram_connected',True) else ('общая пауза' if d['paused'] else 'активен')))
        self.pause_button.configure(text='Возобновить все чаты' if d['paused'] else 'Пауза всех чатов')
        stats=d['stats']; count=stats['requests']
        self.stats_var.set(f'Чатов в белом списке: {len(d["ids"])}\nКонтекст: {d["config"]["context"]:,} токенов\nЗапросов к модели: {count}\nОшибок запросов/формата: {stats["errors"]}\nСгенерировано токенов: {stats["tokens"]}\nПоследняя генерация: {stats["last_seconds"]} с · {stats["last_tps"]} ток/с\nСреднее время запроса: {stats["seconds"]/max(1,count):.2f} с')
        if not self.allow_loaded: self.replace(self.allow_text,'\n'.join(map(str,d['ids']))); self.allow_loaded=True
        if not self.config_loaded:
            c=d['config']; self.context.set(str(c['context'])); self.temp.set(str(c['temperature'])); self.think.set(c['think']); self.review.set(c['review']); self.replace(self.instructions,c['instructions']); self.adaptive.set(c.get('adaptive',True)); self.short_context.set(str(c.get('short_context',8192))); self.chat_limit.set(str(c.get('chat_limit',128))); self.photo_limit.set(str(c.get('photo_limit',192))); self.delay.set(str(c.get('delay',2))); self.config_loaded=True
        for item in self.tree.get_children():
            if int(item) not in d['ids']: self.tree.delete(item)
        for cid,status,note in d['chats']:
            iid=str(cid); vals=(iid,status)
            if self.tree.exists(iid): self.tree.item(iid,values=vals)
            else: self.tree.insert('','end',iid=iid,values=vals)
            if self.current==cid: self.chat_title.set(f'{cid} · {status}')
        self.memory_select['values']=list(map(str,d['ids']))
        if self.memory_payload and not any(str(cid)==str(self.memory_payload['cid']) and status!='нет согласия' for cid,status,_ in d['chats']):
            self.memory_payload=None; self.replace(self.memory_text,'',True); self.memory_info.set('Память недоступна.')
        current_log='\n'.join(d['logs'])
        if current_log!=self.log_snapshot: self.log_snapshot=current_log; self.replace(self.log_text,current_log,True); self.log_text.see('end')
    def toggle_pause(self):
        if self.connected: self.action({'op':'global_pause','value':'0' if self.data.get('paused') else '1'})
    def ollama_live(self):
        try:
            with urllib.request.urlopen('http://127.0.0.1:11434/api/tags',timeout=1) as r: return r.status==200
        except Exception: return False
    def start(self):
        if self.connected or self.starting or (self.proc and self.proc.poll() is None): return
        if not (BASE/'agent.py').exists() or not (BASE/'.env').exists(): messagebox.showerror('Запуск','Положи приложение рядом с agent.py и .env в папке TelegramAI.'); return
        self.starting=True; self.start_time=time.monotonic(); self.console=[]; self.status.set('Запуск…'); self.start_button.configure(state='disabled')
        threading.Thread(target=self.launch,daemon=True).start()
    def launch(self):
        try:
            if not self.ollama_live():
                self.server=subprocess.Popen(['ollama','serve'],cwd=BASE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=FLAGS)
                for _ in range(20):
                    if self.ollama_live(): break
                    time.sleep(.5)
                else: raise RuntimeError('Ollama не запустилась. Открой Ollama из меню Пуск и повтори.')
            env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONIOENCODING='utf-8',TELEGRAM_AI_DESKTOP='1')
            with (BASE/'startup.log').open('w',encoding='utf-8') as output:
                self.proc=subprocess.Popen([str(PYTHON),'-u',str(BASE/'agent.py')],cwd=BASE,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=FLAGS,stdin=subprocess.DEVNULL)
                self.events.put(('exit',self.proc.wait()))
        except Exception as e: self.events.put(('error',str(e)))
    def stop(self):
        if self.connected:
            if self.action({'op':'shutdown'}): self.stop_pending=True; self.status.set('Остановка…')
        elif self.proc and self.proc.poll() is None:
            if messagebox.askyesno('Остановка','Агент ещё не подключился. Завершить процесс?'): self.proc.terminate()
    def check_ollama(self):
        try:
            with urllib.request.urlopen('http://127.0.0.1:11434/api/ps',timeout=2) as r: models=json.load(r).get('models',[])
            self.ollama_var.set('Ollama: '+('\n'.join(f'{m.get("name",m.get("model"))} · VRAM {m.get("size_vram",0)/1e9:.2f} ГБ' for m in models) if models else 'работает, модель не загружена'))
        except Exception: self.ollama_var.set('Ollama: сервер недоступен')
    def unload(self):
        if self.connected and not self.data.get('paused'):
            if not messagebox.askyesno('Выгрузить модель','Сначала поставить все чаты на паузу, чтобы модель не загрузилась снова?'): return
            if not self.action({'op':'global_pause','value':'1'}): return
        try:
            result=subprocess.run(['ollama','stop','qwen3.5:9b'],capture_output=True,timeout=15,creationflags=FLAGS)
            if result.returncode: raise RuntimeError('Ollama не смогла выгрузить модель')
            self.check_ollama()
        except Exception as e: messagebox.showerror('Ollama',str(e))
    def open_log(self):
        f=BASE/'agent.log'
        if f.exists(): os.startfile(str(f))
        else: messagebox.showinfo('Журнал','Журнал появится после запуска агента.')
    def hardware_poll(self):
        if not self.hw_busy:
            self.hw_busy=True; threading.Thread(target=self.hardware_sample,daemon=True).start()
        self.after(5000,self.hardware_poll)
    def hardware_sample(self):
        info=[]
        try:
            import psutil
            cpu=psutil.cpu_percent(interval=.3); ram=psutil.virtual_memory()
            info.append(f'CPU: {cpu:.0f}% · RAM: {ram.used/2**30:.1f} / {ram.total/2**30:.1f} ГБ ({ram.percent:.0f}%)')
        except Exception: info.append('CPU / RAM: установи psutil для мониторинга')
        try:
            proc=subprocess.run(['nvidia-smi','--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=3,creationflags=FLAGS,check=True)
            fields=[x.strip() for x in proc.stdout.splitlines()[0].split(',')]
            util,used,total,temp=fields
            info.append(f'GPU: {util}% · VRAM: {float(used)/1024:.1f} / {float(total)/1024:.1f} ГБ · {temp} °C')
        except Exception: info.append('GPU: nvidia-smi недоступна')
        try:
            with urllib.request.urlopen('http://127.0.0.1:11434/api/ps',timeout=2) as r: models=json.load(r).get('models',[])
            if models:
                m=models[0]; size=m.get('size',0); vram=m.get('size_vram',0)
                info.append(f'Ollama: {m.get("name",m.get("model",""))} · GPU {100*vram/max(size,1):.0f}% объёма модели · контекст {m.get("context_length","—")}')
            else: info.append('Ollama: модель не загружена')
        except Exception: pass
        self.events.put(('hardware','\n'.join(info)))
    def poll(self):
        while True:
            try: kind,value=self.events.get_nowait()
            except queue.Empty: break
            if kind=='hardware':
                self.hw_busy=False; self.hw_var.set(value)
            elif kind=='line':
                self.console.append(value); self.console=self.console[-150:]
                if not self.connected: self.replace(self.log_text,'\n'.join(self.console),True); self.log_text.see('end')
            elif kind in ('exit','error'):
                self.starting=False
                if kind=='error': self.console.append(value); messagebox.showerror('Запуск',value)
        was=self.connected
        try:
            self.update_data(self.api())
        except Exception:
            self.connected=False
            if was:
                self.config_loaded=False; self.allow_loaded=False
                for item in self.tree.get_children(): self.tree.item(item,values=(item,'нет подключения'))
            if self.starting and time.monotonic()-self.start_time>90: self.starting=False
            if self.stop_pending: self.stop_pending=False
            f=BASE/'startup.log'
            if f.exists():
                try:
                    with f.open('rb') as stream:
                        stream.seek(max(0,f.stat().st_size-16000)); tail=stream.read().decode('utf-8',errors='replace')
                    tail='\n'.join(x for x in tail.splitlines() if 'token=' not in x)
                    if tail!=self.log_snapshot: self.log_snapshot=tail; self.replace(self.log_text,tail,True); self.log_text.see('end')
                except OSError: pass
            self.status.set('Запуск…' if self.starting else 'Не подключён — см. журнал')
        self.start_button.configure(state='disabled' if self.connected or self.starting or (self.proc and self.proc.poll() is None) else 'normal')
        self.pause_button.configure(state='normal' if self.connected else 'disabled')
        self.stop_button.configure(state='normal' if self.connected or self.starting else 'disabled')
        self.after(1500,self.poll)
    def close(self):
        # Closing dashboard does not stop the independent agent unless requested.
        if self.connected and messagebox.askyesno('Закрыть приложение','Остановить агент перед закрытием? (Нет — агент продолжит работать)'):
            if not self.action({'op':'shutdown'}): return
        self.destroy()

if __name__=='__main__': App().mainloop()
